# ActionsBuildOpenWRT
Build OpenWRT By Github Actions

这是使用的版本。

经过 docker->hao->openwrt1版本迭代逐渐满足要求，在。config开头会列出与前一版本的改动与不足，test用于新要求的尝试，成功后复制成openwrt2,3....


# 插件中英文名称对照表

###### [luci-app-clash  ](#/README.md) &emsp;&emsp; # clash科学上网（基本上没用的了，已经给luci-app-openclash代替）
###### [luci-app-accesscontrol   ](#/README.md) &emsp;&emsp; # 访问时间控制
###### [luci-app-adblock  ](#/README.md) &emsp;&emsp; # ADB 广告过滤
###### [luci-app-adbyby-plus   ](#/README.md) &emsp;&emsp; # 广告屏蔽大师Plus +
###### [luci-app-adguardhome  ](#/README.md) &emsp;&emsp; # adguardhome广告过滤
###### [luci-app-advanced  ](#/README.md) &emsp;&emsp; # 高级设置（内置[luci-app-fileassistant](#/README.md)文件助手）
###### [luci-app-advanced-reboot  ](#/README.md) &emsp;&emsp; # 高级重启
###### [luci-app-aliyundrive-webdav  ](#/README.md) &emsp;&emsp; # 阿里云盘
###### [luci-app-ahcp  ](#/README.md) &emsp;&emsp; # 支持 AHCPd
###### [luci-app-airplay2  ](#/README.md) &emsp;&emsp; # Apple AirPlay2 无损音频接收服务器
###### [luci-app-aliddns  ](#/README.md) &emsp;&emsp; # 阿里 DDNS
###### [luci-app-amule  ](#/README.md) &emsp;&emsp; # aMule 下载工具
###### [luci-app-argon-config  ](#/README.md) &emsp;&emsp; # argon主题设置,要配合argon主题使用
###### [luci-app-aria2  ](#/README.md) &emsp;&emsp; # Aria2 下载工具
###### [luci-app-arpbind  ](#/README.md) &emsp;&emsp; # IP/MAC 绑定
###### [luci-app-asterisk  ](#/README.md) &emsp;&emsp; # 支持 Asterisk 电话服务器
###### [luci-app-attendedsysupgrade  ](#/README.md) &emsp;&emsp; # 固件更新升级相关
###### [luci-app-autoreboot  ](#/README.md) &emsp;&emsp; # 支持计划重启
###### [luci-app-autoupdate  ](#/README.md) &emsp;&emsp; # 定时更新固件插件
###### [luci-app-baidupcs-web  ](#/README.md) &emsp;&emsp; # 百度网盘管理
###### [luci-app-bcp38  ](#/README.md) &emsp;&emsp; # BCP38 网络入口过滤（不确定）
###### [luci-app-bird1-ipv4  ](#/README.md) &emsp;&emsp; # 对Bird1-ipv4的支持
###### [luci-app-bird1-ipv6  ](#/README.md) &emsp;&emsp; # 对Bird1-ipv6的支持
###### [luci-app-bmx6  ](#/README.md) &emsp;&emsp; # BMX6路由协议
###### [luci-app-cifs-mount  ](#/README.md) &emsp;&emsp; # CIFS/SMB挂载设置 
###### [luci-app-cifsd  ](#/README.md) &emsp;&emsp; # CIFS/SMB网络共享
###### [luci-app-cjdns  ](#/README.md) &emsp;&emsp; # 加密IPV6网络相关
###### [luci-app-clamav  ](#/README.md) &emsp;&emsp; # ClamAV杀毒软件
###### [luci-app-commands  ](#/README.md) &emsp;&emsp; # Shell命令模块
###### [luci-app-control-timewol  ](#/README.md) &emsp;&emsp; # 定时网络设备唤醒
###### [luci-app-control-webrestriction  ](#/README.md) &emsp;&emsp; # 访问限制
###### [luci-app-control-weburl  ](#/README.md) &emsp;&emsp; # 网址过滤
###### [luci-app-cpulimit  ](#/README.md) &emsp;&emsp; # CPU性能调整
###### [luci-app-cshark  ](#/README.md) &emsp;&emsp; # CloudShark捕获工具
###### [luci-app-cupsd  ](#/README.md) &emsp;&emsp; # CUPS 打印服务器
###### [luci-app-ddns  ](#/README.md) &emsp;&emsp; # 动态域名 DNS（集成阿里DDNS客户端）
###### [luci-app-ddnsto  ](#/README.md) &emsp;&emsp; # 内网穿透
###### [luci-app-diag-core  ](#/README.md) &emsp;&emsp; # core诊断工具
###### [luci-app-diskman  ](#/README.md) &emsp;&emsp; # 磁盘管理工具
###### [luci-app-dnscrypt-proxy  ](#/README.md) &emsp;&emsp; # DNSCrypt解决DNS污染
###### [luci-app-dnsforwarder  ](#/README.md) &emsp;&emsp; # DNSForwarder防DNS污染
###### [luci-app-docker  ](#/README.md) &emsp;&emsp; # 不带控制面板的docker
###### [luci-app-dockerman  ](#/README.md) &emsp;&emsp; # 带控制面板的docker
###### [luci-app-dump1090  ](#/README.md) &emsp;&emsp; # 民航无线频率（不确定）
###### [luci-app-dynapoint  ](#/README.md) &emsp;&emsp; # DynaPoint（未知）
###### [luci-app-e2guardian  ](#/README.md) &emsp;&emsp; # Web内容过滤器
###### [luci-app-easymesh  ](#/README.md) &emsp;&emsp; # 简单MESH(可有线+无线回程)
###### [luci-app-eqos  ](#/README.md) &emsp;&emsp; # 内网IP地址限速
###### [luci-app-familycloud  ](#/README.md) &emsp;&emsp; # 家庭云盘
###### [luci-app-fileassistant  ](#/README.md) &emsp;&emsp; # 文件助手
###### [luci-app-filebrowser  ](#/README.md) &emsp;&emsp; # 文件管理器
###### [luci-app-filetransfer  ](#/README.md) &emsp;&emsp; # 文件传输（可web安装ipk包）
###### [luci-app-firewall  ](#/README.md) &emsp;&emsp; # 添加防火墙
###### [luci-app-frpc  ](#/README.md) &emsp;&emsp; # 内网穿透Frp客户端
###### [luci-app-frps  ](#/README.md) &emsp;&emsp; # 内网穿透Frp服务端
###### [luci-app-fwknopd  ](#/README.md) &emsp;&emsp; # Firewall Knock Operator服务器
###### [luci-app-godproxy  ](#/README.md) &emsp;&emsp; # 广告拦截
###### [luci-app-gost  ](#/README.md) &emsp;&emsp; # GO语言实现的安全隧道（隐蔽的https代理）
###### [luci-app-gowebdav  ](#/README.md) &emsp;&emsp; # GoWebDav 是一个轻巧、简单、快速的 WebDav 服务端程序
###### [luci-app-guest-wifi  ](#/README.md) &emsp;&emsp; # WiFi访客网络
###### [luci-app-haproxy-tcp  ](#/README.md) &emsp;&emsp; # HAProxy负载均衡-TCP
###### [luci-app-hd-idle  ](#/README.md) &emsp;&emsp; # 硬盘休眠
###### [luci-app-hnet  ](#/README.md) &emsp;&emsp; # Homenet Status家庭网络控制协议
###### [luci-app-https-dns-proxy  ](#/README.md) &emsp;&emsp; # 通过HTTPS代理为DNS提供Web UI
###### [luci-app-ipsec-vpnserver-manyusers  ](#/README.md) &emsp;&emsp; # ipsec-vpn（VPN服务器）
###### [luci-app-iptvhelper  ](#/README.md) &emsp;&emsp; # iptvhelper,帮助你轻松配置IPTV
###### [luci-app-jd-dailybonus  ](#/README.md) &emsp;&emsp; # 京东签到服务
###### [luci-app-kodexplorer  ](#/README.md) &emsp;&emsp; # KOD可道云私人网盘
###### [luci-app-koolddns  ](#/README.md) &emsp;&emsp; # 支持阿里DDNS、DnsPod动态域名解析
###### [luci-app-linkease  ](#/README.md) &emsp;&emsp; # 易有云文件管理器
###### [luci-app-lxc  ](#/README.md) &emsp;&emsp; # LXC容器管理
###### [luci-app-mentohust  ](#/README.md) &emsp;&emsp; # 锐捷验证
###### [luci-app-minidlna  ](#/README.md) &emsp;&emsp; # 完全兼容DLNA / UPnP-AV客户端的服务器软件
###### [luci-app-mjpg-streamer  ](#/README.md) &emsp;&emsp; # 兼容Linux-UVC的摄像头程序
###### [luci-app-music-remote-center  ](#/README.md) &emsp;&emsp; #PCHiFi 数字转盘遥控
###### [luci-app-mwan3  ](#/README.md) &emsp;&emsp; # MWAN3负载均衡
###### [luci-app-mwan3helper  ](#/README.md) &emsp;&emsp; # MWAN3分流助手
###### [luci-app-n2n_v2  ](#/README.md) &emsp;&emsp; # N2N内网穿透 N2N v2 VPN服务
###### [luci-app-netdata  ](#/README.md) &emsp;&emsp; # 实时监控中文版
###### [luci-app-nfs  ](#/README.md) &emsp;&emsp; # NFS网络共享
###### [luci-app-nft-qos  ](#/README.md) &emsp;&emsp; # QOS流量控制 Nftables版
###### [luci-app-nlbwmon  ](#/README.md) &emsp;&emsp; # 网络带宽监视器
###### [luci-app-noddos  ](#/README.md) &emsp;&emsp; # NodDOS Clients 阻止DDoS攻击（丢弃）
###### [luci-app-nps  ](#/README.md) &emsp;&emsp; # 内网穿透nps
###### [luci-app-ntpc ](#/README.md) &emsp;&emsp; # NTP时间同步服务器
###### [luci-app-oaf  ](#/README.md) &emsp;&emsp; # 应用过滤 
###### [luci-app-ocserv  ](#/README.md) &emsp;&emsp; # OpenConnect VPN服务
###### [luci-app-olsr  ](#/README.md) &emsp;&emsp; # OLSR配置和状态模块
###### [luci-app-olsr-services  ](#/README.md) &emsp;&emsp; # OLSR服务器
###### [luci-app-olsr-viz  ](#/README.md) &emsp;&emsp; # OLSR可视化
###### [luci-app-oled ](#/README.md) &emsp;&emsp; # 为1306 0.91 oled专用，如果oled不显示，[请看这里](https://github.com/NateLol/luci-app-oled/issues/10)
###### [luci-app-onliner   ](#/README.md) &emsp;&emsp; # 流量监控
###### [luci-app-openclash  ](#/README.md) &emsp;&emsp; # openclash
###### [luci-app-openvpn  ](#/README.md) &emsp;&emsp; # OpenVPN客户端
###### [luci-app-openvpn-server  ](#/README.md) &emsp;&emsp; # 易于使用的OpenVPN服务器 Web-UI
###### [luci-app-oscam  ](#/README.md) &emsp;&emsp; # OSCAM服务器
###### [luci-app-p910nd  ](#/README.md) &emsp;&emsp; #打印服务
###### [luci-app-pagekitec  ](#/README.md) &emsp;&emsp; # Pagekitec内网穿透客户端
###### [luci-app-passwall  ](#/README.md) &emsp;&emsp; # 科学上网
###### [luci-app-polipo  ](#/README.md) &emsp;&emsp; # Polipo代理(是一个小型且快速的网页缓存代理)
###### [luci-app-poweroff  ](#/README.md) &emsp;&emsp; # 关机
###### [luci-app-pppoe-relay  ](#/README.md) &emsp;&emsp; # PPPoE NAT穿透 点对点协议（PPP）
###### [luci-app-pppoe-server  ](#/README.md) &emsp;&emsp; # 宽带接入认证服务器
###### [luci-app-pptp-server  ](#/README.md) &emsp;&emsp; # VPN服务器 PPTP
###### [luci-app-privoxy  ](#/README.md) &emsp;&emsp; # Privoxy网络代理(带过滤无缓存)
###### [luci-app-ps3netsrv  ](#/README.md) &emsp;&emsp; # PS3 NET服务器（用于加载蓝光/游戏ISO/PKG）
###### [luci-app-pushbot  ](#/README.md) &emsp;&emsp; # 钉钉推送（微信推送修改版）
###### [luci-app-qbittorrent  ](#/README.md) &emsp;&emsp; # BT下载工具（完整版）
###### [luci-app-qbittorrent_static  ](#/README.md) &emsp;&emsp; # BT下载工具
###### [luci-app-qos  ](#/README.md) &emsp;&emsp; # 流量服务质量(QoS)流控
###### [luci-app-radicale  ](#/README.md) &emsp;&emsp; # CalDAV/CardDAV同步工具
###### [luci-app-ramfree  ](#/README.md) &emsp;&emsp; # 释放内存
###### [luci-app-rclone  ](#/README.md) &emsp;&emsp; # 命令行云端同步工具
###### [luci-app-rebootschedule  ](#/README.md) &emsp;&emsp; # 多功能定时任务（重启网络、重启系统、重启WIFI、重新拨号...）
###### [luci-app-rp-pppoe-server  ](#/README.md) &emsp;&emsp; # Roaring Penguin PPPoE Server 服务器
###### [luci-app-samba  ](#/README.md) &emsp;&emsp; # 网络共享
###### [luci-app-samba4  ](#/README.md) &emsp;&emsp; # 网络共享（Samba4）
###### [luci-app-serverchan  ](#/README.md) &emsp;&emsp; # 微信推送
###### [luci-app-shadowsocks-libev  ](#/README.md) &emsp;&emsp; # SS-libev服务端
###### [luci-app-shairplay  ](#/README.md) &emsp;&emsp; # 支持AirPlay功能
###### [luci-app-siitwizard  ](#/README.md) &emsp;&emsp; # SIIT配置向导  SIIT-Wizzard
###### [luci-app-simple-adblock  ](#/README.md) &emsp;&emsp; # 简单的广告拦截
###### [luci-app-smartdns  ](#/README.md) &emsp;&emsp; # SmartDNS
###### [luci-app-smartinfo  ](#/README.md) &emsp;&emsp; # 穿越蓝天磁盘监控
###### [luci-app-socat   ](#/README.md) &emsp;&emsp; # 多功能的网络工具
###### [luci-app-softethervpn  ](#/README.md) &emsp;&emsp; # SoftEther VPN服务器  NAT穿透
###### [luci-app-splash  ](#/README.md) &emsp;&emsp; # Client-Splash是无线MESH网络的一个热点认证系统
###### [luci-app-store  ](#/README.md) &emsp;&emsp; # 在线商店
###### [luci-app-supervisord  ](#/README.md) &emsp;&emsp; # 一款golang开发的进程管理
###### [luci-app-sqm  ](#/README.md) &emsp;&emsp; # 流量智能队列管理（QOS）
###### [luci-app-squid  ](#/README.md) &emsp;&emsp; # Squid代理服务器
###### [luci-app-ssr-plus  ](#/README.md) &emsp;&emsp; #SSR Plus+ 科学上网
###### [luci-app-ssrserver-python  ](#/README.md) &emsp;&emsp; #ShadowsocksR Python服务器
###### [luci-app-statistics  ](#/README.md) &emsp;&emsp; # 流量监控工具
###### [luci-app-switch-lan-play  ](#/README.md) &emsp;&emsp; # 虚拟局域网联机工具
###### [luci-app-syncdial  ](#/README.md) &emsp;&emsp; # 多拨虚拟网卡（原macvlan）
###### [luci-app-syncthing  ](#/README.md) &emsp;&emsp; # syncthing同步工具
###### [luci-app-tencentddns  ](#/README.md) &emsp;&emsp; # 腾讯DDNS
###### [luci-app-timecontrol  ](#/README.md) &emsp;&emsp; # 时间控制跟（luci-app-accesscontrol）差不多，不同的是这个可以配合高级设置一起使用
###### [luci-app-tinyproxy  ](#/README.md) &emsp;&emsp; # Tinyproxy是 HTTP(S)代理服务器
###### [luci-app-transmission  ](#/README.md) &emsp;&emsp; # BT下载工具
###### [luci-app-travelmate  ](#/README.md) &emsp;&emsp; # 旅行路由器
###### [luci-app-ttnode  ](#/README.md) &emsp;&emsp; # 甜糖星愿自动采集插件
###### [luci-app-ttyd  ](#/README.md) &emsp;&emsp; # 网页终端命令窗
###### [luci-app-turboacc  ](#/README.md) &emsp;&emsp; # Turbo ACC 网络加速
###### [luci-app-udpxy  ](#/README.md) &emsp;&emsp; # udpxy做组播服务器
###### [luci-app-udp2raw  ](#/README.md) &emsp;&emsp; # udp2raw-tunnel管理界面-隧道服务器管理
###### [luci-app-uhttpd  ](#/README.md) &emsp;&emsp; # uHTTPd Web服务器
###### [luci-app-unblockmusic  ](#/README.md) &emsp;&emsp; #解锁网易云灰色歌曲
###### [luci-app-unblockneteasemusic  ](#/README.md) &emsp;&emsp; #新版本解除网易云音乐播放限制
###### [luci-app-unbound  ](#/README.md) &emsp;&emsp; # Unbound DNS解析器
###### [luci-app-upnp  ](#/README.md) &emsp;&emsp; # 通用即插即用UPnP（端口自动转发）
###### [luci-app-usb-printer  ](#/README.md) &emsp;&emsp; # USB 打印服务器
###### [luci-app-uugamebooster  ](#/README.md) &emsp;&emsp; # UU网游加速器
###### [luci-app-v2ray-server  ](#/README.md) &emsp;&emsp; # V2Ray 服务器
###### [luci-app-verysync  ](#/README.md) &emsp;&emsp; # 微力同步
###### [luci-app-vlmcsd  ](#/README.md) &emsp;&emsp; # KMS激活服务器
###### [luci-app-vnstat  ](#/README.md) &emsp;&emsp; # vnStat网络监控（图表）
###### [luci-app-vpnbypass  ](#/README.md) &emsp;&emsp; # VPN BypassWebUI  绕过VPN设置
###### [luci-app-vsftpd  ](#/README.md) &emsp;&emsp; # FTP服务器
###### [luci-app-vssr  ](#/README.md) &emsp;&emsp; # VSSR科学上网
###### [luci-app-watchcat  ](#/README.md) &emsp;&emsp; # 断网检测功能与定时重启
###### [luci-app-webadmin  ](#/README.md) &emsp;&emsp; # Web管理页面设置
###### [luci-app-wifischedule  ](#/README.md) &emsp;&emsp; # WiFi 计划
###### [luci-app-wireguard  ](#/README.md) &emsp;&emsp; # VPN服务器 WireGuard状态
###### [wifidog-wiwiz  ](#/README.md) &emsp;&emsp; # 拼拼WiFi(luci-app-eqos必选，然后在Network ---> Captive Portals ---> wifidog-wiwiz 勾选上)
###### [luci-app-wolplus  ](#/README.md) &emsp;&emsp; # 新版网络唤醒，替换luci-app-wol
###### [luci-app-wrtbwmon  ](#/README.md) &emsp;&emsp; # 实时流量监测
###### [luci-app-webd  ](#/README.md) &emsp;&emsp; # Webd 是一款轻量级的 (self-hosted) 自建网盘
###### [luci-app-xlnetacc  ](#/README.md) &emsp;&emsp; # 迅雷快鸟
###### [luci-app-zerotier  ](#/README.md) &emsp;&emsp; # ZeroTier内网穿透
###### [luci-theme-Light  ](#/README.md) &emsp;&emsp; # Light 主题
###### [luci-theme-argon  ](#/README.md) &emsp;&emsp; # argon 主题
###### [luci-theme-atmaterial  ](#/README.md) &emsp;&emsp; # atmaterial 主题
###### [luci-theme-bootstrap  ](#/README.md) &emsp;&emsp; # bootstrap 主题
###### [luci-theme-darkmatter  ](#/README.md) &emsp;&emsp; # 黑色 主题
###### [luci-theme-infinityfreedom  ](#/README.md) &emsp;&emsp; # 透明效果 主题
###### [luci-theme-material  ](#/README.md) &emsp;&emsp; # material 主题
###### [luci-theme-netgear  ](#/README.md) &emsp;&emsp; # 网件 主题
###### [luci-theme-neobird  ](#/README.md) &emsp;&emsp; # neobird 主题
###### [luci-theme-opentomcat  ](#/README.md) &emsp;&emsp; # opentomcat 主题
###### [luci-theme-rosy  ](#/README.md) &emsp;&emsp; # rosy 主题

---
```yaml
luci-app-dockerman 和 luci-app-docker 只能二选一

想要编译luci-app-dockerman或者luci-app-docker

首先要在Global build settings ---> Enable IPv6 support in packages (NEW)（选上）

选择dockerman或docker建议选上luci-app-diskman方便挂盘所用 
```

- 插件会根据情况而变动的，以后此列表就不更新了，以当时编译时候为准，如果您有什么插件想增加，而那个插件又确实可以在源码内使用的，可以告诉我，我增加上
